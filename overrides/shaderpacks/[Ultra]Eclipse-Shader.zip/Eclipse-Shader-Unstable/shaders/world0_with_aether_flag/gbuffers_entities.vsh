#version 430 compatibility


#define WORLD
#define ENTITIES

#define OVERWORLD_SHADER
#define AETHER_FLAG

#include "/dimensions/all_solid.vsh"