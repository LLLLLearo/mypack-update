#version 430 compatibility

#define OVERWORLD_SHADER

#include "/dimensions/DH_solid.vsh"